"""Click-to-add interface with explicit computation, clear and export buttons."""

from .diagram import construct
from .frame import inferred_box
from .geometry import Point
from .io import write_csv, write_json
from .visualize import draw


class InteractiveController:
    def __init__(
        self,
        figure,
        axes,
        sites=(),
        box=None,
        output="interactive.png",
        *,
        delaunay=False,
    ):
        self.figure, self.axes = figure, axes
        self.sites = list(sites)
        self.sites = [
            p if isinstance(p, Point) else Point(float(p[0]), float(p[1]))
            for p in self.sites
        ]
        self.box = box if box is not None else inferred_box(self.sites)
        self.delaunay = delaunay
        self.output = output
        self.diagram = None
        self.replays = []
        self.status = figure.text(
            0.13,
            0.02,
            "Click to add sites; Compute or double-click to build.",
            fontsize=9,
        )
        self.figure.canvas.mpl_connect("button_press_event", self.click)
        self.clear_axes()

    def clear_axes(self):
        self.axes.clear()
        b = self.box
        self.axes.set(
            xlim=(b.xmin, b.xmax),
            ylim=(b.ymin, b.ymax),
            xlabel="x",
            ylabel="y",
            title="Fortune sweep | click to add points",
        )
        self.axes.set_aspect("equal")
        if self.sites:
            self.axes.scatter(
                [p.x for p in self.sites], [p.y for p in self.sites], c="black"
            )

    def click(self, event):
        if event.inaxes is not self.axes or event.button != 1 or event.xdata is None:
            return
        if event.dblclick:
            self.compute()
            return
        self.sites.append(Point(event.xdata, event.ydata))
        self.diagram = None
        self.clear_axes()
        self.status.set_text(
            f"{len(self.sites)} input sites; compute to update the cells."
        )
        self.figure.canvas.draw_idle()

    def compute(self, event=None):
        if not self.sites:
            self.status.set_text("Add at least one site first.")
            return
        try:
            self.diagram = construct(self.sites, self.box)
            draw(self.diagram, self.axes, delaunay=self.delaunay)
            stats = self.diagram.statistics
            self.status.set_text(
                f"{stats['unique_sites']} cells; {stats['construction_seconds']:.4f} s. Export saves image, CSV and JSON."
            )
        except (ValueError, ArithmeticError) as exc:
            self.status.set_text(str(exc))
        self.figure.canvas.draw_idle()

    def toggle_delaunay(self, label=None):
        self.delaunay = not self.delaunay
        if self.diagram is not None:
            draw(self.diagram, self.axes, delaunay=self.delaunay)
            self.figure.canvas.draw_idle()

    def clear(self, event=None):
        self.sites.clear()
        self.diagram = None
        self.clear_axes()
        self.status.set_text("Cleared. Click to add new sites.")
        self.figure.canvas.draw_idle()

    def animate(self, event=None):
        from pathlib import Path

        from .replay_canvas import launch

        if not self.sites:
            self.status.set_text("Add at least one site first.")
        else:
            try:
                path = Path(self.output)
                replay = launch(
                    self.sites,
                    self.box,
                    path.with_name(path.stem + "-replay.html"),
                    block=False,
                )
                self.replays.append(replay)
                self.status.set_text(
                    "Pointer replay opened in the browser. Move over the diagram."
                )
            except (ValueError, ArithmeticError) as exc:
                self.status.set_text(str(exc))
        self.figure.canvas.draw_idle()

    def export(self, event=None):
        from pathlib import Path

        if self.diagram is None:
            self.compute()
        if self.diagram is None:
            return
        path = Path(self.output)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.figure.savefig(path, dpi=160)
        write_csv(self.diagram, path.with_suffix(".csv"))
        write_json(self.diagram, path.with_suffix(".json"))
        self.status.set_text(f"Saved {path.name}, CSV and JSON.")
        self.figure.canvas.draw_idle()


def launch(sites=(), box=None, output="interactive.png", *, delaunay=False):
    import matplotlib.pyplot as plt
    from matplotlib.widgets import Button, CheckButtons

    fig, axes = plt.subplots(figsize=(9, 8))
    fig.subplots_adjust(bottom=0.22)
    controller = InteractiveController(fig, axes, sites, box, output, delaunay=delaunay)
    controller.dual_control = CheckButtons(
        fig.add_axes([0.12, 0.14, 0.2, 0.04]), ["Delaunay"], [delaunay]
    )
    controller.dual_control.on_clicked(controller.toggle_delaunay)
    controller.buttons = []
    for x, label, callback in (
        (0.12, "Compute", controller.compute),
        (0.32, "Animate", controller.animate),
        (0.52, "Clear", controller.clear),
        (0.72, "Export", controller.export),
    ):
        button = Button(fig.add_axes([x, 0.075, 0.15, 0.05]), label)
        button.on_clicked(callback)
        controller.buttons.append(button)
    plt.show()
    return controller
