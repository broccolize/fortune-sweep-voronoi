"""Small geometric primitives, with explicit singular cases and filtered signs."""

import math
from dataclasses import dataclass
from decimal import Decimal, localcontext
from fractions import Fraction


@dataclass(frozen=True, slots=True)
class Point:
    x: float
    y: float

    def distance(self, other: "Point") -> float:
        return math.hypot(self.x - other.x, self.y - other.y)


@dataclass(frozen=True, slots=True)
class Box:
    xmin: float
    ymin: float
    xmax: float
    ymax: float

    def __post_init__(self):
        if not all(math.isfinite(v) for v in self.as_tuple()):
            raise ValueError("Bounding-box coordinates must be finite")
        if self.xmin >= self.xmax or self.ymin >= self.ymax:
            raise ValueError("Bounding box must have positive width and height")

    def as_tuple(self):
        return self.xmin, self.ymin, self.xmax, self.ymax


def orient(a: Point, b: Point, c: Point) -> float:
    """Positive for CCW. Exact dyadic fallback resolves uncertain float products.

    This is a filtered predicate, not arbitrary-precision construction: input
    coordinates and returned circumcentres are still IEEE double precision.
    """
    ux, uy = b.x - a.x, b.y - a.y
    vx, vy = c.x - a.x, c.y - a.y
    left, right = ux * vy, uy * vx
    det = left - right
    if abs(det) > 8e-16 * (abs(left) + abs(right)):
        return det
    ax, ay, bx, by, cx, cy = map(Fraction, (a.x, a.y, b.x, b.y, c.x, c.y))
    exact = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
    try:
        value = float(exact)
    except OverflowError:
        value = math.inf if exact > 0 else -math.inf
    if value == 0.0 and exact:
        return math.copysign(math.ulp(0.0), 1 if exact > 0 else -1)
    return value


def circumcircle(a: Point, b: Point, c: Point):
    """Return (centre, radius), or None for exactly collinear input.

    Translation to a local origin avoids subtracting large squared coordinates.
    For cancellation-prone determinants, recompute the construction in Decimal.
    """
    # Anchor at the closest pair. Subtracting a distant origin from two very
    # close sites can destroy their separation in the squared-length numerators
    # even when the determinant itself is well conditioned.
    a, b, c = min(
        ((a, b, c), (b, c, a), (c, a, b)),
        key=lambda triple: triple[0].distance(triple[1]),
    )
    ux, uy = b.x - a.x, b.y - a.y
    vx, vy = c.x - a.x, c.y - a.y
    cross = ux * vy - uy * vx
    # A reliable determinant sign alone does not imply an accurate centre.
    # Ill-conditioned (almost collinear) triples need high-precision coordinates.
    u2, v2 = ux * ux + uy * uy, vx * vx + vy * vy
    nx, ny = u2 * vy - v2 * uy, ux * v2 - vx * u2
    if (
        abs(cross) <= 1e-8 * (abs(ux * vy) + abs(uy * vx))
        or abs(nx) <= 1e-8 * (abs(u2 * vy) + abs(v2 * uy))
        or abs(ny) <= 1e-8 * (abs(ux * v2) + abs(vx * u2))
    ):
        with localcontext() as ctx:
            ctx.prec = 80
            ax, ay = Decimal(a.x), Decimal(a.y)
            u, v = Decimal(b.x) - ax, Decimal(b.y) - ay
            s, t = Decimal(c.x) - ax, Decimal(c.y) - ay
            d = 2 * (u * t - v * s)
            if not d:
                return None
            u2, s2 = u * u + v * v, s * s + t * t
            centre = Point(
                float(ax + (u2 * t - s2 * v) / d), float(ay + (u * s2 - s * u2) / d)
            )
    else:
        centre = Point(
            a.x + nx / (2 * cross),
            a.y + ny / (2 * cross),
        )
    radius = centre.distance(a)
    if not math.isfinite(radius):
        raise ArithmeticError("Circumcircle is outside the supported float range")
    return centre, radius


def parabola_y(focus: Point, x: float, directrix: float) -> float:
    gap = focus.y - directrix
    if gap <= 0:
        raise ValueError("A finite beach parabola needs its focus above the directrix")
    return (x - focus.x) ** 2 / (2 * gap) + (focus.y + directrix) / 2


def breakpoint_x(left: Point, right: Point, directrix: float) -> float:
    """Breakpoint between consecutive arcs in a downward sweep.

    Equal-height sites give a linear equation. A focus on the directrix gives
    a vertical limiting arc. The remaining quadratic is solved with a stable
    two-root formula, in coordinates translated to the lower focus. That origin
    avoids subtracting a distant upper focus from a breakpoint near a new site.
    """
    if left.y == right.y:
        return left.x + (right.x - left.x) / 2
    if left.y <= directrix:
        return left.x
    if right.y <= directrix:
        return right.x
    a, b = (left, right) if left.y < right.y else (right, left)
    dp, dq = a.y - directrix, b.y - directrix
    dx = b.x - a.x
    aa = b.y - a.y
    bb = 2 * dp * dx
    cc = -dp * dx * dx - aa * dp * dq
    discr = bb * bb - 4 * aa * cc
    # Roundoff may make a mathematically nonnegative discriminant slightly negative.
    if discr < 0:
        if discr < -2e-14 * (bb * bb + abs(4 * aa * cc)):
            raise ArithmeticError("Negative breakpoint discriminant")
        discr = 0.0
    q = -0.5 * (bb + math.copysign(math.sqrt(discr), bb))
    roots = (q / aa, cc / q) if q else (-bb / (2 * aa),) * 2
    root = min(roots) if left.y > right.y else max(roots)
    return a.x + root


def circle_bottom(centre: Point, through: Point) -> float:
    """Avoid cancellation in centre.y - radius when the centre is high above."""
    dx, dy = centre.x - through.x, centre.y - through.y
    radius = math.hypot(dx, dy)
    if dy >= 0 and radius + dy:
        return through.y - dx * dx / (radius + dy)
    return centre.y - radius


def breakpoint_side(left, right, directrix, x):
    """Compare x with a breakpoint, resolving close searches exactly.

    The quadratic's vertex separates its two roots. On the selected branch,
    evaluating its sign compares x to that root without rounding a square root.
    """
    boundary = breakpoint_x(left, right, directrix)
    error = 32 * math.ulp(max(1.0, abs(left.x), abs(right.x), abs(x), abs(boundary)))
    if abs(x - boundary) > error:
        return -1 if x < boundary else 1
    lx, ly, rx, ry, s, query = map(
        Fraction, (left.x, left.y, right.x, right.y, directrix, x)
    )
    if ly == ry:
        value = 2 * query - lx - rx
    elif ly <= s:
        value = query - lx
    elif ry <= s:
        value = query - rx
    else:
        ax, ay, bx, by = (lx, ly, rx, ry) if ly < ry else (rx, ry, lx, ly)
        dp, dq, dx, u = ay - s, by - s, bx - ax, query - ax
        aa, bb = by - ay, 2 * dp * dx
        cc = -dp * dx * dx - aa * dp * dq
        side_of_axis = 2 * aa * u + bb
        value_at_query = aa * u * u + bb * u + cc
        if ly > ry:
            if side_of_axis >= 0:
                return 1
            value = -value_at_query
        else:
            if side_of_axis <= 0:
                return -1
            value = value_at_query
    return (value > 0) - (value < 0)


def circle_identity(a, b, c):
    """Exact circle identity for grouping events, not a rounded-centre hash.

    Coordinates are finite input doubles, hence exact dyadic fractions. Keeping
    distinct circles distinct also preserves real tiny edges between vertices.
    """
    ax, ay, bx, by, cx, cy = map(Fraction, (a.x, a.y, b.x, b.y, c.x, c.y))
    ux, uy, vx, vy = bx - ax, by - ay, cx - ax, cy - ay
    denominator = 2 * (ux * vy - uy * vx)
    if not denominator:
        return None
    u2, v2 = ux * ux + uy * uy, vx * vx + vy * vy
    x = ax + (u2 * vy - v2 * uy) / denominator
    y = ay + (ux * v2 - vx * u2) / denominator
    return x, y, (x - ax) ** 2 + (y - ay) ** 2


def polygon_area(points) -> float:
    if len(points) < 3:
        return 0.0
    origin = points[0]
    return (
        abs(
            math.fsum(
                orient(origin, points[i], points[i + 1])
                for i in range(1, len(points) - 1)
            )
        )
        / 2
    )
