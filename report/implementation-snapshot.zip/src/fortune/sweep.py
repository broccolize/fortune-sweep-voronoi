"""Fortune's event-driven sweep, producing adjacency and traced Voronoi edges.

No cell is constructed here using comparisons with every other site. The
adjacency graph is generated only by site splits and disappearing arcs.
"""

import math
from dataclasses import dataclass, field

from .beachline import Arc, BeachLine
from .circle import candidate_circle
from .events import Event, EventQueue
from .geometry import Point, circle_identity, orient


@dataclass(slots=True)
class Vertex:
    point: Point
    defining: set[int]


@dataclass(slots=True)
class TraceEdge:
    sites: tuple[int, int]
    vertices: list[int] = field(default_factory=list)


class FortuneSweep:
    def __init__(self, points, debug=False, original_points=None):
        self.points = points
        self.original_points = (
            original_points if original_points is not None else points
        )
        self.debug = debug
        self.beach = BeachLine()
        self.queue = EventQueue()
        self.sweep_y = math.inf
        self.neighbours = [set() for _ in points]
        self.edges = {}
        self.vertices = []
        self._vertex_index = {}
        self.statistics = dict(site_events=0, circle_events=0, stale_events=0)
        self._started = False
        self._level = None

    def edge(self, a, b, vertex=None):
        if a == b:
            raise ArithmeticError("An edge cannot separate a site from itself")
        key = (min(a, b), max(a, b))
        if key not in self.edges:
            self.edges[key] = TraceEdge(key)
            self.neighbours[a].add(b)
            self.neighbours[b].add(a)
        edge = self.edges[key]
        if vertex is not None and vertex not in edge.vertices:
            edge.vertices.append(vertex)
        return edge

    def schedule(self, arc):
        if arc is None or not arc.alive:
            return
        arc.generation += 1
        if arc.prev is None or arc.next is None:
            return
        ids = (arc.prev.site, arc.site, arc.next.site)
        if orient(*(self.original_points[i] for i in ids)) >= 0:
            return
        result = candidate_circle(*(self.points[i] for i in ids), self.sweep_y)
        if result:
            centre, bottom = result
            event = Event(
                bottom,
                centre.x,
                1,
                arc=arc,
                generation=arc.generation,
                centre=centre,
                defining=ids,
                circle_points=tuple(self.points[i] for i in ids),
            )
            level = self._level
            if level is None and math.isfinite(self.sweep_y):
                level = Event(self.sweep_y, 0, 0).height
            if level is None or event.height.compare(level) <= 0:
                self.queue.push(event)

    def site_event(self, site):
        self.statistics["site_events"] += 1
        if self.beach.root is None:
            self.beach.insert_after(None, Arc(site))
            return
        point = self.points[site]
        # A preceding circle height may round a fraction of an ulp below this
        # site. Search at the site's exact birth level, not that display height.
        old = self.beach.locate(point.x, point.y, self.points)
        before, after = old.prev, old.next
        old.generation += 1
        if self.points[old.site].y == point.y:
            # A whole equal-height batch has vertical limiting parabolas. It
            # inserts an adjacent arc instead of splitting a finite parabola.
            new = Arc(site)
            self.beach.insert_after(
                old if point.x >= self.points[old.site].x else old.prev, new
            )
            self.edge(old.site, site)
            for arc in (before, old, new, after):
                self.schedule(arc)
            return
        new, right = Arc(site), Arc(old.site)
        self.beach.insert_after(old, new)
        self.beach.insert_after(new, right)
        self.edge(old.site, site)
        for arc in (before, old, new, right, after):
            self.schedule(arc)

    def circle_event(self, event):
        middle = event.arc
        if not middle.alive or middle.generation != event.generation:
            self.statistics["stale_events"] += 1
            return
        left, right = middle.prev, middle.next
        if (
            left is None
            or right is None
            or (left.site, middle.site, right.site) != event.defining
        ):
            raise ArithmeticError("A valid circle event lost its neighbourhood")
        key = circle_identity(*(self.original_points[i] for i in event.defining))
        if key is None:
            self.statistics["stale_events"] += 1
            return
        vertex = self._vertex_index.get(key)
        if vertex is None:
            vertex = len(self.vertices)
            self.vertices.append(Vertex(event.centre, set(event.defining)))
            self._vertex_index[key] = vertex
        else:
            self.vertices[vertex].defining.update(event.defining)
        self.edge(left.site, middle.site, vertex)
        self.edge(middle.site, right.site, vertex)
        self.edge(left.site, right.site, vertex)
        self.beach.remove(middle)
        self.statistics["circle_events"] += 1
        self.schedule(left)
        self.schedule(right)

    def start(self):
        """Queue sites once; replay and batch execution share this entry point."""
        if not self._started:
            for i, p in enumerate(self.points):
                self.queue.push(Event(p.y, p.x, 0, site=i))
            self._started = True
        return self

    def step(self):
        """Process exactly one heap entry, including an invalidated prediction.

        Return the processed event, or None after completion. The same handlers
        and generation guard are used by ordinary construction and replay.
        """
        self.start()
        if not self.queue:
            self._finish_statistics()
            return None
        event = self.queue.pop()
        self._level = event.height
        self.sweep_y = min(self.sweep_y, event.y)
        if event.kind == 0:
            self.site_event(event.site)
        else:
            self.circle_event(event)
        if self.debug:
            self.beach.validate()
        if not self.queue:
            self._finish_statistics()
        return event

    def _finish_statistics(self):
        self.statistics.update(
            queue_peak=self.queue.peak_size,
            events_pushed=self.queue.pushed,
            beach_max_height=self.beach.max_height,
            trace_edges=len(self.edges),
        )

    def run(self):
        while self.step() is not None:
            pass
        return self


def collinear_neighbours(points):
    """One-dimensional degeneration: consecutive sites alone share bisectors."""
    sweep = FortuneSweep(points)
    order = sorted(range(len(points)), key=lambda i: (points[i].x, points[i].y))
    for a, b in zip(order, order[1:]):
        sweep.edge(a, b)
    sweep.statistics["collinear_special_case"] = True
    return sweep


def all_collinear(points):
    if len(points) < 3:
        return True
    a, b = min(points, key=lambda p: (p.x, p.y)), max(points, key=lambda p: (p.x, p.y))
    return all(orient(a, b, p) == 0 for p in points)
